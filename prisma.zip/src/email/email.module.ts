import { Module } from '@nestjs/common';
import { EmailService } from './email.service';
import { AppConfigService } from '../config/config.service';

@Module({ providers: [EmailService, AppConfigService], exports: [EmailService] })
export class EmailModule {}
