import { Injectable } from '@nestjs/common';
import { AppConfigService } from '../config/config.service';
import * as sgMail from '@sendgrid/mail';

@Injectable()
export class EmailService {
  constructor(private readonly config: AppConfigService) {
    sgMail.setApiKey(this.config.get('SENDGRID_API_KEY'));
  }
  async sendInvite(email: string, token: string) {
    const link = `${this.config.get('APP_BASE_URL')}/auth/complete-invite?token=${token}`;
    await sgMail.send({ to: email, from: this.config.get('EMAIL_FROM') || 'no-reply@domain.com', subject: 'Invite', html: `<a href="${link}">Set your password</a>` });
  }
}
