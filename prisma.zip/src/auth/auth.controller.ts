import { Controller, Post, Body, Get, Query, UseGuards, Request } from '@nestjs/common';
import { AuthService } from './auth.service';
import { JwtAuthGuard } from '@nestjs/passport';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { Role } from '@prisma/client';

@Controller('auth')
export class AuthController {
  constructor(private auth: AuthService) {}
  @Post('invite-user') @UseGuards(JwtAuthGuard,RolesGuard) @Roles(Role.Admin) invite(@Body() dto){return this.auth.inviteUser(dto.email,dto.role,dto.tenantId);}  
  @Get('validate-invite') validate(@Query('token') t){return this.auth.validateInvite(t);}  
  @Post('complete-invite') complete(@Body('token')t,@Body('password')p){return this.auth.completeInvite(t,p);}  
  @Post('login') login(@Body('email')e,@Body('password')p){return this.auth.login(e,p);}  
}
