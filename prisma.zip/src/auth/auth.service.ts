import { Injectable, BadRequestException, UnauthorizedException } from '@nestjs/common';
import { PrismaService } from '../database/prisma.service';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';
import { v4 as uuid } from 'uuid';
import { EmailService } from '../email/email.service';

@Injectable()
export class AuthService {
  constructor(private prisma: PrismaService, private jwt: JwtService, private email: EmailService) {}

  async inviteUser(email: string, role: string, tenantId: string) {
    const existing = await this.prisma.user.findUnique({ where: { email } });
    if (existing) throw new BadRequestException('User exists');
    const user = await this.prisma.user.create({ data: { email, role, tenantId } });
    const token = uuid();
    await this.prisma.inviteToken.create({ data: { token, userId: user.id, expiresAt: new Date(Date.now()+3*86400000) } });
    await this.email.sendInvite(email, token);
  }

  async validateInvite(token: string) {
    const rec = await this.prisma.inviteToken.findUnique({ where: { token }, include:{user:true} });
    if (!rec || rec.used || rec.expiresAt < new Date()) throw new BadRequestException('Invalid');
    return rec;
  }

  async completeInvite(token: string, password: string) {
    const rec = await this.validateInvite(token);
    const hash = await bcrypt.hash(password, 10);
    await this.prisma.user.update({ where:{id:rec.userId}, data:{passwordHash:hash, invited:false} });
    await this.prisma.inviteToken.update({ where:{token}, data:{used:true} });
    return this.login(rec.user.email, password);
  }

  async login(email: string, pass: string) {
    const user = await this.prisma.user.findUnique({ where:{email} });
    if (!user?.passwordHash) throw new UnauthorizedException();
    const ok = await bcrypt.compare(pass, user.passwordHash);
    if (!ok) throw new UnauthorizedException();
    const payload = { sub:user.id, role:user.role, tenantId:user.tenantId };
    return { access_token: this.jwt.sign(payload) };
  }
}
