import { Controller, Get, Param, Query, UseGuards, Request } from '@nestjs/common';
import { BookingsService } from './bookings.service';
import { JwtAuthGuard } from '@nestjs/passport';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { Role } from '@prisma/client';

@Controller('bookings')@UseGuards(JwtAuthGuard,RolesGuard)
export class BookingsController {
  constructor(private svc:BookingsService){}
  @Get() @Roles(Role.Admin,Role.Editor,Role.Communicator)
  list(@Request()r,@Query('search')s?:string,@Query('date')d?:string){return this.svc.findAll(r.user.tenantId,s,d);}  
  @Get(':id') @Roles(Role.Admin,Role.Editor,Role.Communicator) one(@Request()r,@Param('id')i){return this.svc.findOne(r.user.tenantId,i);}  
}
