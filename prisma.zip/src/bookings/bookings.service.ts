import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../database/prisma.service';

@Injectable()
export class BookingsService {
  constructor(private prisma:PrismaService){}
  findAll(t:string,s?:string,d?:string){
    const where: any = { tenantId: t };
    if (s) where.OR = [
      { id: { contains: s } },
      { client: { name: { contains: s, mode: 'insensitive' } } }
    ];
    if (d) where.date = new Date(d);
    return this.prisma.booking.findMany({ where });
  }
  async findOne(t<string,i<string){
    const b = await this.prisma.booking.findFirst({ where: { tenantId: t, id: i } });
    if (!b) throw new NotFoundException();
    return b;
  }
}
