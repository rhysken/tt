import { Controller, Get, Param, UseGuards, Request } from '@nestjs/common';
import { JwtAuthGuard } from '@nestjs/passport';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { Role } from '@prisma/client';
import { UsersService } from './users.service';

@Controller('users')@UseGuards(JwtAuthGuard,RolesGuard)
export class UsersController {
  constructor(private svc:UsersService){}
  @Get() @Roles(Role.Admin) all(@Request()r){return this.svc.findAll(r.user.tenantId);}  
  @Get(':id') @Roles(Role.Admin) one(@Param('id')i){return this.svc.findOne(i);}  
}
