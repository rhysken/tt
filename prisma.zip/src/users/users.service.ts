import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../database/prisma.service';

@Injectable()
export class UsersService {
  constructor(private prisma: PrismaService) {}
  findAll(tenantId:string){return this.prisma.user.findMany({where:{tenantId}});}  
  findOne(id:string){return this.prisma.user.findUnique({where:{id}});}  
}
