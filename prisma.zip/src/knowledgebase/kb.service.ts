import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../database/prisma.service';

@Injectable()
export class KnowledgebaseService {
  constructor(private prisma:PrismaService){}
  create(t:string,d:any){return this.prisma.knowledgeBaseItem.create({data:{tenantId:t,...d}});}  
  findAll(t:string,s?:string){return this.prisma.knowledgeBaseItem.findMany({where:{tenantId:t,...(s?{title:{contains:s,mode:'insensitive'}}:{})}});}  
  async findOne(t:string,i:number){const k=await this.prisma.knowledgeBaseItem.findFirst({where:{tenantId:t,id:i}});if(!k)throw new NotFoundException();return k;}  
  update(t:string,i:number,d<any){return this.prisma.knowledgeBaseItem.update({where:{id:i},data:d});}  
  remove(t<string,i:number){return this.prisma.knowledgeBaseItem.delete({where:{id:i}});}  
}
