import { Module } from '@nestjs/common';
import { KnowledgebaseService } from './kb.service';
import { KnowledgebaseController } from './kb.controller';
import { PrismaModule } from '../database/prisma.module';

@Module({imports:[PrismaModule],providers:[KnowledgebaseService],controllers:[KnowledgebaseController]})
export class KnowledgebaseModule {}
