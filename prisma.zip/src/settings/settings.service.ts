import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../database/prisma.service';
import { CreateSettingDto } from './dto/create-setting.dto';
import { UpdateSettingDto } from './dto/update-setting.dto';

@Injectable()
export class SettingsService {
  constructor(private prisma:PrismaService){}
  create(t:string,d:CreateSettingDto){return this.prisma.setting.create({data:{tenantId:t,...d}});}  
  findAll(t:string,s?:string){return this.prisma.setting.findMany({where:{tenantId:t,...(s?{key:{contains:s,mode:'insensitive'}}:{})}});}  
  async findOne(t:string,i:number){const s=await this.prisma.setting.findFirst({where:{tenantId:t,id:i}});if(!s)throw new NotFoundException();return s;}  
  update(t:string,i:number,d:UpdateSettingDto){return this.prisma.setting.update({where:{id:i},data:d});}  
  remove(t:string,i:number){return this.prisma.setting.delete({where:{id:i}});}  
}
