import { Controller, Get, Post, Patch, Delete, Body, Param, UseGuards, Request, Query } from '@nestjs/common';
import { SettingsService } from './settings.service';
import { CreateSettingDto } from './dto/create-setting.dto';
import { UpdateSettingDto } from './dto/update-setting.dto';
import { JwtAuthGuard } from '@nestjs/passport';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { Role } from '@prisma/client';

@Controller('settings')@UseGuards(JwtAuthGuard,RolesGuard)
export class SettingsController {
  constructor(private svc:SettingsService){}
  @Post() @Roles(Role.Admin,Role.Editor) create(@Request()r,@Body()dto:CreateSettingDto){return this.svc.create(r.user.tenantId,dto);}  
  @Get() @Roles(Role.Admin,Role.Editor,Role.Communicator) list(@Request()r,@Query('search')s?:string){return this.svc.findAll(r.user.tenantId,s);}  
  @Get(':id') @Roles(Role.Admin,Role.Editor,Role.Communicator) one(@Request()r,@Param('id')i){return this.svc.findOne(r.user.tenantId,Number(i));}  
  @Patch(':id') @Roles(Role.Admin,Role.Editor) update(@Request()r,@Param('id')i,@Body()dto:UpdateSettingDto){return this.svc.update(r.user.tenantId,Number(i),dto);}  
  @Delete(':id') @Roles(Role.Admin) remove(@Request()r,@Param('id')i){return this.svc.remove(r.user.tenantId,Number(i));}  
}
