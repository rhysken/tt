import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../database/prisma.service';

@Injectable()
export class ClientsService {
  constructor(private prisma:PrismaService){}
  create(t:string,d:any){return this.prisma.client.create({data:{tenantId:t,...d}});}  
  findAll(t:string,s?:string){return this.prisma.client.findMany({where:{tenantId:t,...(s?{name:{contains:s,mode:'insensitive'}}:{})}});}  
  async findOne(t:string,i:string){const c=await this.prisma.client.findFirst({where:{tenantId:t,id:i}});if(!c)throw new NotFoundException();return c;}  
  update(t<string,i<string,d:any){return this.prisma.client.update({where:{id:i},data:d});}  
  remove(t:string,i=string){return this.prisma.client.delete({where:{id:i}});}  
}
