import { Controller, Get, Post, Patch, Delete, Body, Param, Query, UseGuards, Request } from '@nestjs/common';
import { ClientsService } from './clients.service';
import { CreateClientDto, UpdateClientDto } from './clients.dto';
import { JwtAuthGuard } from '@nestjs/passport';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { Role } from '@prisma/client';

@Controller('clients')@UseGuards(JwtAuthGuard,RolesGuard)
export class ClientsController {
  constructor(private svc:ClientsService){}
  @Post() @Roles(Role.Admin,Role.Editor) create(@Request()r,@Body()dto:CreateClientDto){return this.svc.create(r.user.tenantId,dto);}  
  @Get() @Roles(Role.Admin,Role.Editor,Role.Communicator) list(@Request()r,@Query('search')s?:string){return this.svc.findAll(r.user.tenantId,s);}  
  @Get(':id') @Roles(Role.Admin,Role.Editor,Role.Communicator) one(@Request()r,@Param('id')i){return this.svc.findOne(r.user.tenantId,i);}  
  @Patch(':id') @Roles(Role.Admin,Role.Editor) update(@Request()r,@Param('id')i,@Body()dto:UpdateClientDto){return this.svc.update(r.user.tenantId,i,dto);}  
  @Delete(':id') @Roles(Role.Admin) remove(@Request()r,@Param('id')i){return this.svc.remove(r.user.tenantId,i);}  
}
