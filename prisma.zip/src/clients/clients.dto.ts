import { IsString, IsOptional, IsBoolean, IsNumber } from 'class-validator';
export class CreateClientDto{ @IsString() name:string; @IsOptional() @IsString() email?:string; @IsOptional() @IsString() phone?:string; @IsOptional() @IsNumber() totalSpend?:number; @IsOptional() @IsBoolean() marketing?:boolean; }
export class UpdateClientDto extends PartialType(CreateClientDto) {}
