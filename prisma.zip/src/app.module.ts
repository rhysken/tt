
// ===== src/app.module.ts =====
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { PrismaModule } from './database/prisma.module';
import { AuthModule } from './auth/auth.module';
import { TenantsModule } from './tenants/tenant.module';
import { UsersModule } from './users/users.module';
import { SettingsModule } from './settings/settings.module';
import { KnowledgebaseModule } from './knowledgebase/kb.module';
import { ClientsModule } from './clients/clients.module';
import { BookingsModule } from './bookings/bookings.module';
import { EmailModule } from './email/email.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    PrismaModule,
    AuthModule,
    TenantsModule,
    UsersModule,
    SettingsModule,
    KnowledgebaseModule,
    ClientsModule,
    BookingsModule,
    EmailModule,
  ],
})
export class AppModule {}