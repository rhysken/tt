// ===== src/config/config.service.ts =====
import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class AppConfigService {
  constructor(private readonly config: ConfigService) {}
  get(key: string): string { return this.config.get<string>(key) || ''; }
}